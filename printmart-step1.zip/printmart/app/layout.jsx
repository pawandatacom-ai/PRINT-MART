import"./globals.css";import Header from"@/components/Header";import{CartProvider}from"@/lib/cart";import Link from"next/link";
export const metadata={title:"PRINTMART – All Your Printing Needs Under One Roof",description:"Banners, visiting cards, T-shirts, mugs and more."};
export default function Root({children}){
  const wa=process.env.NEXT_PUBLIC_WHATSAPP_NUMBER||"";
  return<html lang="en"><body><CartProvider><Header/>{children}
    <a href={`https://wa.me/${wa}`} target="_blank" className="fixed bottom-5 right-5 z-50 bg-green-500 text-white rounded-full px-4 py-3 shadow-lg font-semibold">WhatsApp</a>
    <footer className="bg-navy text-slate-300 mt-20"><div className="max-w-7xl mx-auto px-4 py-10 grid md:grid-cols-3 gap-8 text-sm">
      <div><div className="text-xl font-extrabold text-white">PRINT<span className="text-brand">MART</span></div><p className="mt-2">All your printing needs under one roof.</p></div>
      <div><b className="text-white">Contact</b><p className="mt-2">Your address here<br/>+91 99999 99999<br/>hello@printmart.example</p></div>
      <div><b className="text-white">Policies</b><p className="mt-2 space-y-1"><Link href="/shop" className="block">Shipping & Delivery</Link><span className="block">Refund & Cancellation</span><span className="block">Privacy Policy</span><span className="block">Terms</span></p></div></div>
      <div className="text-center text-xs py-4 border-t border-slate-700">© PRINTMART. All rights reserved.</div></footer>
  </CartProvider></body></html>;
}
