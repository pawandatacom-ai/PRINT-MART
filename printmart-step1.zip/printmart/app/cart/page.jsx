"use client";
import Link from"next/link";import{useCart}from"@/lib/cart";import{inr}from"@/lib/data";
export default function Cart(){
  const{items,remove,subtotal}=useCart();
  if(!items.length)return<main className="max-w-3xl mx-auto p-10 text-center"><p>Your cart is empty.</p><Link href="/shop" className="btn-brand mt-4">Browse products</Link></main>;
  return<main className="max-w-4xl mx-auto px-4 py-8"><h1 className="text-2xl font-bold text-navy mb-4">Your Cart</h1>
    <div className="space-y-3">{items.map(i=><div key={i.id} className="card p-4 flex justify-between gap-4">
      <div><div className="font-semibold text-navy">{i.name}</div><div className="text-sm text-slate-600">{i.size} • {i.material} • {i.printing} • Qty {i.qty}</div>
        <div className="text-xs text-slate-500">{i.fileName?`Design: ${i.fileName}`:"No design uploaded"}</div></div>
      <div className="text-right"><div className="font-bold text-brand">{inr(i.total)}</div><button onClick={()=>remove(i.id)} className="text-sm text-red-600">Remove</button></div></div>)}</div>
    <div className="mt-6 text-right"><div className="text-xl font-bold">Subtotal: {inr(subtotal)}</div>
      <button disabled className="btn-brand mt-3 opacity-50 cursor-not-allowed">Checkout (coming in Step 2)</button></div></main>;
}
