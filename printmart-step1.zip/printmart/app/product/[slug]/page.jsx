"use client";
import{useParams,useRouter}from"next/navigation";import{useState}from"react";
import{getProduct,CATEGORIES,TIERS,calc,inr}from"@/lib/data";import{useCart}from"@/lib/cart";
export default function Product(){
  const{slug}=useParams();const p=getProduct(slug);const{add}=useCart();const r=useRouter();
  const[s,setS]=useState(0),[m,setM]=useState(0),[pt,setPt]=useState(0);
  const[qty,setQty]=useState(p?.min||1);const[file,setFile]=useState(null);const[err,setErr]=useState("");const[ok,setOk]=useState(false);const[g,setG]=useState(0);
  if(!p)return<p className="p-8">Product not found.</p>;
  const icon=CATEGORIES.find(c=>c.slug===p.cat).icon;const pr=calc(p,s,m,pt,qty);
  const pick=e=>{const f=e.target.files[0];setErr("");if(!f)return setFile(null);
    if(!["application/pdf","image/jpeg","image/png"].includes(f.type)){setFile(null);return setErr("Only PDF, JPG or PNG allowed")}
    if(f.size>10*1024*1024){setFile(null);return setErr("File must be under 10 MB")}setFile(f)};
  const item=()=>({slug:p.slug,name:p.name,size:p.sizes[s][0],material:p.materials[m][0],printing:p.printing[pt][0],qty,unit:pr.unit,total:pr.total,fileName:file?.name||null});
  const valid=()=>{if(!Number.isInteger(qty)||qty<p.min||qty>100000){setErr(`Quantity must be ${p.min} to 100000`);return false}return true};
  const sel=(label,opts,val,set)=><label className="block"><span className="text-sm font-semibold text-navy">{label}</span>
    <select value={val} onChange={e=>set(+e.target.value)} className="mt-1 w-full border rounded-lg px-3 py-2">{opts.map((o,i)=><option key={i} value={i}>{o[0]}</option>)}</select></label>;
  return<main className="max-w-6xl mx-auto px-4 py-8 grid md:grid-cols-2 gap-10">
    <div><div className="h-80 rounded-2xl grid place-items-center text-8xl bg-gradient-to-br from-slate-100 to-orange-100">{icon}</div>
      <div className="flex gap-2 mt-3">{[0,1,2].map(i=><button key={i} onClick={()=>setG(i)} className={"h-16 w-16 rounded-lg border grid place-items-center text-2xl "+(g===i?"border-brand":"")}>{icon}</button>)}</div>
      <p className="text-xs text-slate-500 mt-2">Placeholder images — upload real product photos from the admin panel (Step 3).</p></div>
    <div className="space-y-4"><h1 className="text-3xl font-extrabold text-navy">{p.name}</h1><p>{p.desc}</p>
      {sel("Size",p.sizes,s,setS)}{sel("Paper / Material",p.materials,m,setM)}{sel("Printing type",p.printing,pt,setPt)}
      <label className="block"><span className="text-sm font-semibold text-navy">Quantity (min {p.min})</span>
        <input type="number" min={p.min} value={qty} onChange={e=>setQty(parseInt(e.target.value)||0)} className="mt-1 w-full border rounded-lg px-3 py-2"/></label>
      <div className="text-xs text-slate-500">Bulk discount: {TIERS.slice(1).map(t=>`${t.min}+ → ${t.off*100}% off`).join(" • ")}</div>
      <label className="block"><span className="text-sm font-semibold text-navy">Upload design (PDF, JPG, PNG — max 10 MB)</span>
        <input type="file" accept=".pdf,.jpg,.jpeg,.png" onChange={pick} className="mt-1 block w-full text-sm"/></label>
      <div className="rounded-xl bg-orange-50 p-4"><div className="text-sm">{inr(pr.unit)} per unit {pr.off>0&&<b className="text-green-700">({pr.off*100}% bulk discount)</b>}</div>
        <div className="text-3xl font-extrabold text-brand">{inr(pr.total)}</div><div className="text-sm text-slate-600">Estimated delivery: {p.days} working days</div></div>
      {err&&<p className="text-red-600 text-sm">{err}</p>}{ok&&<p className="text-green-700 text-sm">Added to cart ✓</p>}
      <div className="flex gap-3"><button className="btn-navy flex-1" onClick={()=>{if(valid()){add(item());setOk(true);setTimeout(()=>setOk(false),2000)}}}>Add to Cart</button>
        <button className="btn-brand flex-1" onClick={()=>{if(valid()){add(item());r.push("/cart")}}}>Buy Now</button></div>
      <p className="text-xs text-slate-500">Design files are only saved securely once Step 2 (Supabase storage) is connected.</p></div></main>;
}
