"use client";
import Link from"next/link";import{useState}from"react";
import{CATEGORIES,PRODUCTS,calc,inr}from"@/lib/data";
const wa=process.env.NEXT_PUBLIC_WHATSAPP_NUMBER||"";
function Thumb({icon,className=""}){return<div className={"grid place-items-center bg-gradient-to-br from-slate-100 to-orange-100 "+className}><span className="text-5xl">{icon}</span></div>}
export default function Home(){
  const[f,setF]=useState({name:"",phone:"",item:"",qty:""});const[err,setErr]=useState("");
  const send=e=>{e.preventDefault();
    if(f.name.trim().length<2)return setErr("Enter your name");
    if(!/^[6-9]\d{9}$/.test(f.phone))return setErr("Enter a valid 10-digit Indian mobile number");
    if(!f.item.trim())return setErr("Tell us what you need");
    setErr("");const t=`Bulk enquiry%0AName: ${f.name}%0APhone: ${f.phone}%0AItem: ${f.item}%0AQty: ${f.qty}`;
    window.open(`https://wa.me/${wa}?text=${t}`,"_blank")};
  const best=PRODUCTS.slice(0,8);
  return<main>
    <section className="bg-gradient-to-br from-navy to-slate-800 text-white"><div className="max-w-7xl mx-auto px-4 py-16 md:py-24 grid md:grid-cols-2 gap-10 items-center">
      <div className="fade"><span className="bg-brand/20 text-brand px-3 py-1 rounded-full text-sm font-semibold">Premium Quality • Fast Delivery</span>
        <h1 className="text-4xl md:text-5xl font-extrabold mt-4 leading-tight">All Your Printing Needs <span className="text-brand">Under One Roof</span></h1>
        <p className="mt-4 text-slate-300">Banners, cards, T-shirts, mugs and gifts — upload your design, pick options, see the price instantly.</p>
        <div className="mt-6 flex gap-3 flex-wrap"><Link href="/shop" className="btn-brand">Shop Now</Link><a href="#bulk" className="btn border border-white/40 hover:bg-white/10">Bulk Enquiry</a></div></div>
      <div className="grid grid-cols-3 gap-3 fade">{CATEGORIES.slice(0,6).map(c=><div key={c.slug} className="bg-white/10 rounded-xl p-5 text-center text-4xl">{c.icon}</div>)}</div></div></section>
    <section className="max-w-7xl mx-auto px-4 mt-14"><h2 className="text-2xl font-bold text-navy">Shop by Category</h2>
      <div className="mt-5 grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">{CATEGORIES.map(c=>
        <Link key={c.slug} href={`/shop?cat=${c.slug}`} className="card p-4 text-center"><div className="text-4xl">{c.icon}</div><div className="mt-2 text-sm font-semibold text-navy">{c.name}</div></Link>)}</div></section>
    <section className="max-w-7xl mx-auto px-4 mt-14"><h2 className="text-2xl font-bold text-navy">Best Selling Products</h2>
      <div className="mt-5 grid grid-cols-2 lg:grid-cols-4 gap-4">{best.map(p=>{const c=CATEGORIES.find(x=>x.slug===p.cat);
        return<Link key={p.slug} href={`/product/${p.slug}`} className="card overflow-hidden"><Thumb icon={c.icon} className="h-36"/>
          <div className="p-4"><div className="font-semibold text-navy">{p.name}</div><div className="text-brand font-bold mt-1">From {inr(calc(p,0,0,0,p.min).unit)}</div></div></Link>})}</div></section>
    <section className="max-w-7xl mx-auto px-4 mt-14"><div className="rounded-2xl bg-orange-50 p-8 md:p-12 grid md:grid-cols-2 gap-6 items-center">
      <div><h2 className="text-2xl font-bold text-navy">Custom Printing</h2><p className="mt-2">Have your own artwork? Upload PDF, JPG or PNG on any product page and we print it exactly as you designed.</p></div>
      <div className="md:text-right"><Link href="/shop" className="btn-brand">Start Customising</Link></div></div></section>
    <section id="bulk" className="max-w-3xl mx-auto px-4 mt-14 scroll-mt-24"><h2 className="text-2xl font-bold text-navy">Bulk Order Enquiry</h2>
      <form onSubmit={send} className="mt-5 grid gap-3 card p-6">
        <input className="border rounded-lg px-3 py-2" placeholder="Your name" value={f.name} onChange={e=>setF({...f,name:e.target.value})}/>
        <input className="border rounded-lg px-3 py-2" placeholder="Mobile number" inputMode="numeric" maxLength={10} value={f.phone} onChange={e=>setF({...f,phone:e.target.value.replace(/\D/g,"")})}/>
        <input className="border rounded-lg px-3 py-2" placeholder="What do you need?" value={f.item} onChange={e=>setF({...f,item:e.target.value})}/>
        <input className="border rounded-lg px-3 py-2" placeholder="Quantity" value={f.qty} onChange={e=>setF({...f,qty:e.target.value})}/>
        {err&&<p className="text-red-600 text-sm">{err}</p>}<button className="btn-brand">Send on WhatsApp</button></form></section>
    <section id="how" className="max-w-7xl mx-auto px-4 mt-14 scroll-mt-24"><h2 className="text-2xl font-bold text-navy">How It Works</h2>
      <div className="mt-5 grid md:grid-cols-4 gap-4">{["Choose product","Select size & material","Upload your design","We print & deliver"].map((s,i)=>
        <div key={s} className="card p-5"><div className="w-9 h-9 rounded-full bg-brand text-white grid place-items-center font-bold">{i+1}</div><div className="mt-3 font-semibold text-navy">{s}</div></div>)}</div></section>
    <section className="max-w-7xl mx-auto px-4 mt-14"><h2 className="text-2xl font-bold text-navy">Customer Reviews</h2>
      <p className="text-xs text-slate-500">Sample text — replace with real customer reviews.</p>
      <div className="mt-4 grid md:grid-cols-3 gap-4">{["Banner quality was excellent and delivered on time.","Visiting cards looked very premium.","Easy to upload my design and order."].map((t,i)=>
        <div key={i} className="card p-5"><div className="text-brand">★★★★★</div><p className="mt-2 text-sm">{t}</p></div>)}</div></section>
  </main>;
}
