"use client";
import Link from"next/link";import{Suspense}from"react";import{useSearchParams}from"next/navigation";
import{CATEGORIES,PRODUCTS,calc,inr}from"@/lib/data";
function List(){
  const sp=useSearchParams();const cat=sp.get("cat")||"";const q=(sp.get("q")||"").toLowerCase();
  const list=PRODUCTS.filter(p=>(!cat||p.cat===cat)&&(!q||(p.name+p.desc).toLowerCase().includes(q)));
  return<main className="max-w-7xl mx-auto px-4 py-8">
    <div className="flex gap-2 flex-wrap mb-6"><Link href="/shop" className={"px-3 py-1 rounded-full border "+(!cat?"bg-navy text-white":"")}>All</Link>
      {CATEGORIES.map(c=><Link key={c.slug} href={`/shop?cat=${c.slug}`} className={"px-3 py-1 rounded-full border text-sm "+(cat===c.slug?"bg-navy text-white":"")}>{c.name}</Link>)}</div>
    {!list.length&&<p>No products found.</p>}
    <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">{list.map(p=><Link key={p.slug} href={`/product/${p.slug}`} className="card p-4">
      <div className="h-28 grid place-items-center text-5xl bg-slate-50 rounded-lg">{CATEGORIES.find(c=>c.slug===p.cat).icon}</div>
      <div className="mt-3 font-semibold text-navy">{p.name}</div><div className="text-sm text-slate-500 line-clamp-2">{p.desc}</div>
      <div className="text-brand font-bold mt-1">From {inr(calc(p,0,0,0,p.min).unit)}</div></Link>)}</div></main>;
}
export default function Shop(){return<Suspense fallback={<p className="p-8">Loading…</p>}><List/></Suspense>}
