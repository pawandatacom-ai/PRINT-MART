"use client";
import Link from"next/link";import{useRouter}from"next/navigation";import{useState}from"react";
import{useCart}from"@/lib/cart";
export default function Header(){
  const{count}=useCart();const r=useRouter();const[q,setQ]=useState("");const[open,setOpen]=useState(false);
  const go=e=>{e.preventDefault();r.push("/shop?q="+encodeURIComponent(q.trim()))};
  return<header className="sticky top-0 z-40 bg-white/95 backdrop-blur border-b">
    <div className="bg-navy text-white text-xs text-center py-1">Free delivery on orders above ₹999 • Bulk discounts available</div>
    <div className="max-w-7xl mx-auto px-4 py-3 flex items-center gap-4">
      <Link href="/" className="text-2xl font-extrabold text-navy">PRINT<span className="text-brand">MART</span></Link>
      <form onSubmit={go} className="hidden md:flex flex-1 max-w-xl">
        <input value={q} onChange={e=>setQ(e.target.value)} placeholder="Search banners, cards, mugs…" className="flex-1 border rounded-l-lg px-4 py-2 outline-none focus:border-brand"/>
        <button className="bg-brand text-white px-5 rounded-r-lg font-semibold">Search</button></form>
      <nav className="ml-auto hidden md:flex items-center gap-5 font-medium text-navy">
        <Link href="/shop">Shop</Link><Link href="/#bulk">Bulk Order</Link><Link href="/#how">How It Works</Link>
        <Link href="/cart" className="btn-navy !py-2">Cart ({count})</Link></nav>
      <button onClick={()=>setOpen(!open)} className="md:hidden ml-auto text-2xl" aria-label="Menu">☰</button></div>
    {open&&<div className="md:hidden px-4 pb-4 space-y-3 text-navy font-medium" onClick={()=>setOpen(false)}>
      <form onSubmit={go} className="flex"><input value={q} onChange={e=>setQ(e.target.value)} placeholder="Search…" className="flex-1 border rounded-l-lg px-3 py-2"/><button className="bg-brand text-white px-4 rounded-r-lg">Go</button></form>
      <Link className="block" href="/shop">Shop</Link><Link className="block" href="/#bulk">Bulk Order</Link><Link className="block" href="/cart">Cart ({count})</Link></div>}
  </header>;
}
